
package com.example.churn.controller;

import com.example.churn.model.Customer;
import com.example.churn.service.CustomerService;
import com.example.churn.service.PredictionService;
import jakarta.websocket.server.PathParam;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/churn")
public class CustomerController {

    private final CustomerService service;
    private final PredictionService predictionService;

    public CustomerController(CustomerService service, PredictionService predictionService) {
        this.service = service;
        this.predictionService = predictionService;
    }

    @GetMapping("/customers")
    public List<Customer> getCustomers() {
        return service.getAllCustomers();
    }

    @GetMapping("/churn-count")
    public long getChurnCount() {
        return service.getChurnCount();
    }

    @PostMapping("/predict")
    public double predict(@RequestBody Customer customer) {
        return predictionService.predictChurn(customer);
    }

    @GetMapping("/predict-by-customer/{id}")
    public double predictByCustomerId(@PathVariable("id") String customerId) {
        Customer c = service.getCustomer(customerId);
        if( null != c) {
            return predictionService.predictChurn(c);
        } else {
            return 0.0;
        }
    }
}