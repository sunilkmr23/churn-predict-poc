package com.example.churn.service;

import com.example.churn.model.Customer;
import org.springframework.stereotype.Service;

@Service
public class PredictionService {

    public double predictChurn(Customer c) {
        int score = 0;

        // Simple rules (POC)
        if (c.getTenure() < 12) score += 2;
        if (c.getMonthlyCharges() > 70) score += 2;
        if ("Month-to-month".equalsIgnoreCase(c.getContract())) score += 3;

        return score / (4) ;
    }
}