package com.example.churn.controller;

import com.example.churn.model.Customer;
import com.example.churn.service.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/churn")
public class CustomerController {

    private final CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    @GetMapping("/customers")
    public List<Customer> getCustomers() {
        return service.getAllCustomers();
    }

    @GetMapping("/churn-count")
    public long getChurnCount() {
        return service.getChurnCount();
    }
}
