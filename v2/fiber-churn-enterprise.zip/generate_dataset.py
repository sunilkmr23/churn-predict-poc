
import pandas as pd, random
rows=[]
plans=[('Basic',699),('Plus',999),('Premium',1499),('Ultra',2499)]
for i in range(10000):
    plan,price=random.choice(plans)
    tenure=random.randint(1,60)
    outages=random.randint(0,10)
    complaints=random.randint(0,8)
    support=random.randint(0,8)
    late=random.randint(0,6)
    competitor=random.randint(0,1)
    contract=random.randint(0,1)
    speed={'Basic':100,'Plus':200,'Premium':500,'Ultra':1000}[plan]
    churn=1 if (outages>4 or complaints>4 or (tenure<6 and competitor)) else 0
    rows.append([plan,price,tenure,outages,complaints,support,late,competitor,contract,speed,churn])
pd.DataFrame(rows,columns=['plan','monthlyPrice','tenureMonths','outages','complaints','supportCalls','latePayments','competitorAvailable','monthlyContract','speedMbps','churn']).to_csv('fiber_customers.csv',index=False)
print('dataset generated')
