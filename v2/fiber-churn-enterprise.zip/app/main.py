
from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd, joblib

app=FastAPI(title='Fiber Churn Intelligence')

model=joblib.load('churn_model.pkl')
cols=joblib.load('model_columns.pkl')

class Customer(BaseModel):
    plan:str
    monthlyPrice:float
    tenureMonths:int
    outages:int
    complaints:int
    supportCalls:int
    latePayments:int
    competitorAvailable:int
    monthlyContract:int
    speedMbps:int

@app.post('/predict')
def predict(c:Customer):
    df=pd.DataFrame([c.model_dump()])
    df=pd.get_dummies(df,columns=['plan'])
    df=df.reindex(columns=cols,fill_value=0)
    prob=float(model.predict_proba(df)[0][1])
    pred=int(model.predict(df)[0])
    return {
      'churn_prediction':pred,
      'churn_probability':round(prob,4),
      'risk':'HIGH' if prob>0.7 else 'MEDIUM' if prob>0.4 else 'LOW'
    }

@app.get('/feature-importance')
def feature_importance():
    return dict(zip(cols,model.feature_importances_.tolist()))
