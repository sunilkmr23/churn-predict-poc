
import pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
df=pd.read_csv('fiber_customers.csv')
df=pd.get_dummies(df,columns=['plan'])
X=df.drop('churn',axis=1)
y=df['churn']
m=RandomForestClassifier(n_estimators=100,random_state=42)
m.fit(X,y)
joblib.dump(m,'churn_model.pkl')
joblib.dump(X.columns.tolist(),'model_columns.pkl')
print('model trained')
